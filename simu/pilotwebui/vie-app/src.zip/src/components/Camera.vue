<script setup>
import { ref, watch, onMounted, onUnmounted } from 'vue'
import { useTelemetryStore } from '../stores/telemetry'

const displayedSpeed = ref(0)

// === Constantes image ===
const IMAGE_WIDTH = 640
const IMAGE_HEIGHT = 480

// === Store (HUD vitesse) ===
const telemetry = useTelemetryStore()

// === Refs Vue ===
const canvasRef = ref(null)

let ws = null
let ctx = null
let resizeObserver = null

// Queue d’images
const imageQueue = []
let drawing = false

function resizeCanvas() {
  const canvas = canvasRef.value
  if (!canvas) return

  const rect = canvas.getBoundingClientRect()
  canvas.width = rect.width
  canvas.height = rect.height
}

function drawNextImage() {
  if (drawing || imageQueue.length === 0) return

  drawing = true
  const blob = imageQueue.shift()
  const img = new Image()

  img.onload = () => {
    ctx.clearRect(0, 0, canvasRef.value.width, canvasRef.value.height)

    const x = (canvasRef.value.width - IMAGE_WIDTH) / 2
    const y = (canvasRef.value.height - IMAGE_HEIGHT) / 2

    ctx.drawImage(img, x, y, IMAGE_WIDTH, IMAGE_HEIGHT)

    URL.revokeObjectURL(img.src)
    drawing = false
    drawNextImage()
  }

  img.onerror = () => {
    console.error('Erreur de chargement image caméra')
    drawing = false
    drawNextImage()
  }

  img.src = URL.createObjectURL(blob)
}

function connectWebSocket() {
  ws = new WebSocket('ws://localhost:8080') // ← à adapter
  ws.binaryType = 'blob'

  ws.onopen = () => {
    console.log('🟢 WebSocket caméra connecté')
  }

  ws.onmessage = (event) => {
    imageQueue.push(event.data)
    drawNextImage()
  }

  ws.onerror = (err) => {
    console.error('WebSocket caméra erreur:', err)
  }

  ws.onclose = () => {
    console.log('🔴 WebSocket caméra fermé')
  }
}

watch(
  () => telemetry.vehicle.speed,
  (newSpeed) => {
    displayedSpeed.value += (newSpeed - displayedSpeed.value) * 0.2
  }
)

onMounted(() => {
  const canvas = canvasRef.value
  ctx = canvas.getContext('2d')

  resizeCanvas()
  window.addEventListener('resize', resizeCanvas)

  connectWebSocket()
})

onUnmounted(() => {
  window.removeEventListener('resize', resizeCanvas)
  if (ws) ws.close()
})
</script>

<template>
  <div class="camera-container">
    <!-- Canvas caméra -->
    <canvas ref="canvasRef" class="camera-canvas"></canvas>

    <!-- HUD vitesse -->
    <div class="speed-hud">
      <div class="speed-value">
        {{ Math.round(displayedSpeed) }}
      </div>
      <div class="speed-unit">km/h</div>
    </div>
  </div>
</template>

<style scoped>
.camera-container {
  position: relative;
  width: 100%;
  height: 100%;
  background: black;
  overflow: hidden;
}

.camera-canvas {
  width: 100%;
  height: 100%;
  display: block;
}

/* HUD vitesse */
.speed-hud {
  position: absolute;
  bottom: 20px;
  right: 20px;
  display: flex;
  align-items: flex-end;
  color: #ff0015;
  text-shadow:
    0 0 8px rgba(255, 0, 21, 0.8),
    0 0 16px rgba(255, 0, 55, 0.4);
  pointer-events: none;
}

.speed-value {
  font-size: 4rem;
  font-weight: 700;
  line-height: 1;
}

.speed-unit {
  font-size: 1.2rem;
  margin-left: 6px;
  margin-bottom: 6px;
  opacity: 0.8;
}
</style>
