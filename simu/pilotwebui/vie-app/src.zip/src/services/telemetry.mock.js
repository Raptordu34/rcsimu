import { useTelemetryStore } from '../stores/telemetry'

export function startMockTelemetry() {
  const telemetry = useTelemetryStore()

  setInterval(() => {
    telemetry.updateSpeed(Math.random() * 130)
  }, 200)
}
