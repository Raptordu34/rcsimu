<script setup>
import Camera from '../components/Camera.vue'
import DrivingInfo from '../components/DrivingInfo.vue'
</script>

<template>
  <div class="container-fluid p-3">
    <div class="row">
      <div class="col-12 col-lg-9">
        <Camera />
      </div>

      <div class="col-12 col-lg-3">
        <DrivingInfo />
      </div>
    </div>
  </div>
</template>
