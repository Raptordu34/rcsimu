import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { startMockTelemetry } from './services/telemetry.mock'
import App from './App.vue'

// Bootstrap the Vue application
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap-icons/font/bootstrap-icons.css'

// Global CSS
import './assets/css/styles.css'

const app = createApp(App)
app.use(createPinia())
app.mount('#app')

// ⚠️ DEV ONLY
startMockTelemetry()
