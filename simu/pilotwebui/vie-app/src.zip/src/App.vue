<script setup>
import DashboardView from './views/DashboardView.vue'
</script>

<template>
  <DashboardView />
</template>
